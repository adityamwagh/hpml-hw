import matplotlib as plt
import numpy as np

step2_times = []
step3_times = []

plt.plot(step2_times, step3_times)
